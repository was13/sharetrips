package com.example.yongs.sharetrips.common;

public class Common {
    public static final String BaseURL = "http://ec2-3-14-252-120.us-east-2.compute.amazonaws.com:8080";
}
